﻿namespace PixelPhoto.NiceArt.Models
{
    public enum ViewType
    {
        BrushDrawing,
        Text,
        Image,
        Emojis
    }
}